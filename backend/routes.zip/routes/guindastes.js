/**
 * routes/guindastes.js
 * CRUD de guindastes — migração gradual do Supabase.
 * Descomentar cada rota conforme o service for implementado.
 */

const { Router } = require('express');
const asyncHandler = require('../utils/asyncHandler');
const res_ = require('../utils/response');
const svc = require('../services/guindastes.Service');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = Router();

router.get('/', requireAuth, asyncHandler(async (req, res) => {
  const { ativo } = req.query;
  const filter = {};
  if (typeof ativo !== 'undefined') filter.ativo = ativo === 'true';
  const data = await svc.findAll(filter);
  return res_.ok(res, data, { count: data.length });
}));

router.get('/:id', requireAuth, asyncHandler(async (req, res) => {
  const data = await svc.findById(req.params.id);
  if (!data) return res_.notFound(res, 'Guindaste não encontrado');
  return res_.ok(res, data);
}));

router.post('/', requireAuth, requireAdmin, asyncHandler(async (_req, res) => {
  return res_.badRequest(res, 'Rota /POST guindastes ainda não implementada');
}));

router.put('/:id', requireAuth, requireAdmin, asyncHandler(async (_req, res) => {
  return res_.badRequest(res, 'Rota /PUT guindastes ainda não implementada');
}));

router.delete('/:id', requireAuth, requireAdmin, asyncHandler(async (req, res) => {
  const deleted = await svc.remove(req.params.id);
  if (!deleted) return res_.notFound(res, 'Guindaste não encontrado');
  return res_.ok(res, { message: 'Guindaste removido' });
}));

module.exports = router;
