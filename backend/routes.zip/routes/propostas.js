/**
 * routes/propostas.js
 * Leitura/escrita de propostas — migração gradual do Supabase.
 */

const { Router } = require('express');
const asyncHandler = require('../utils/asyncHandler');
const res_ = require('../utils/response');
const svc = require('../services/propostasService');
const { requireAuth } = require('../middleware/auth');

const router = Router();

router.get('/', requireAuth, asyncHandler(async (req, res) => {
  const { status, limit, offset } = req.query;
  const vendedor_id = req.user.role === 'admin' ? undefined : req.user.id;
  const data = await svc.findAll({
    vendedor_id,
    status,
    limit: parseInt(limit) || 50,
    offset: parseInt(offset) || 0,
  });
  return res_.ok(res, data, { count: data.length });
}));

router.get('/:id', requireAuth, asyncHandler(async (req, res) => {
  const data = await svc.findById(req.params.id);
  if (!data) return res_.notFound(res, 'Proposta não encontrada');
  return res_.ok(res, data);
}));

router.post('/', requireAuth, asyncHandler(async (_req, res) => {
  return res_.badRequest(res, 'Rota /POST propostas ainda não implementada');
}));

router.put('/:id', requireAuth, asyncHandler(async (_req, res) => {
  return res_.badRequest(res, 'Rota /PUT propostas ainda não implementada');
}));

module.exports = router;
