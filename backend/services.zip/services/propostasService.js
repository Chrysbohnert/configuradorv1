/**
 * propostasService.js
 * Queries SQL para a tabela `propostas`.
 */

const { query } = require('../db/pool');

async function findAll({ vendedor_id, status, limit = 50, offset = 0 } = {}) {
  const conditions = [];
  const params = [];

  if (vendedor_id) { params.push(vendedor_id); conditions.push(`vendedor_id = $${params.length}`); }
  if (status)      { params.push(status);      conditions.push(`status = $${params.length}`); }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  params.push(limit, offset);

  const { rows } = await query(
    `SELECT id, numero_proposta, vendedor_nome, cliente_nome, valor_total,
            status, created_at, produto_principal
     FROM propostas
     ${where}
     ORDER BY created_at DESC
     LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  return rows;
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM propostas WHERE id = $1`, [id]);
  return rows[0] || null;
}

async function create(data) {
  // TODO: implementar quando migrar propostas do Supabase
  throw new Error('propostasService.create - não implementado');
}

async function update(id, data) {
  // TODO: implementar quando migrar propostas do Supabase
  throw new Error('propostasService.update - não implementado');
}

module.exports = { findAll, findById, create, update };
