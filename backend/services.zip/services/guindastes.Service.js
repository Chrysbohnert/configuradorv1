/**
 * guindastesService.js
 * Queries SQL para a tabela `guindastes`.
 */

const { query } = require('../db/pool');

async function findAll({ ativo } = {}) {
  const where = typeof ativo !== 'undefined' ? 'WHERE ativo = $1' : '';
  const params = typeof ativo !== 'undefined' ? [ativo] : [];
  const { rows } = await query(
    `SELECT * FROM guindastes ${where} ORDER BY nome ASC`,
    params
  );
  return rows;
}

async function findById(id) {
  const { rows } = await query(`SELECT * FROM guindastes WHERE id = $1`, [id]);
  return rows[0] || null;
}

async function create(data) {
  // TODO: implementar quando migrar guindastes do Supabase
  throw new Error('guindastesService.create - não implementado');
}

async function update(id, data) {
  // TODO: implementar quando migrar guindastes do Supabase
  throw new Error('guindastesService.update - não implementado');
}

async function remove(id) {
  const { rowCount } = await query(`DELETE FROM guindastes WHERE id = $1`, [id]);
  return rowCount > 0;
}

module.exports = { findAll, findById, create, update, remove };
