/**
 * usersService.js
 * Toda query SQL relacionada a usuários fica aqui.
 * Controllers chamam funções deste service — nunca escrevem SQL diretamente.
 */

const { query } = require('../db/pool');

const COLS_PUBLIC = `id, nome, email, role, regiao, regioes_operacao, ativo, created_at`;

async function findAll({ ativo } = {}) {
  const conditions = [];
  const params = [];

  if (typeof ativo !== 'undefined') {
    params.push(ativo);
    conditions.push(`ativo = $${params.length}`);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const sql = `SELECT ${COLS_PUBLIC} FROM users ${where} ORDER BY nome ASC`;
  const { rows } = await query(sql, params);
  return rows;
}

async function findById(id) {
  const { rows } = await query(
    `SELECT ${COLS_PUBLIC} FROM users WHERE id = $1`,
    [id]
  );
  return rows[0] || null;
}

async function findByEmail(email) {
  const { rows } = await query(
    `SELECT id, nome, email, senha, role, regiao, regioes_operacao, ativo
     FROM users
     WHERE email = $1`,
    [email.toLowerCase().trim()]
  );
  return rows[0] || null;
}

async function create({ nome, email, senhaHash, role, regiao, regioes_operacao }) {
  const { rows } = await query(
    `INSERT INTO users (nome, email, senha, role, regiao, regioes_operacao, ativo)
     VALUES ($1, $2, $3, $4, $5, $6, true)
     RETURNING ${COLS_PUBLIC}`,
    [nome, email.toLowerCase().trim(), senhaHash, role || 'vendedor', regiao || null, regioes_operacao || null]
  );
  return rows[0];
}

async function update(id, fields) {
  const { nome, email, role, regiao, regioes_operacao, ativo } = fields;
  const { rows } = await query(
    `UPDATE users
     SET nome               = COALESCE($1, nome),
         email              = COALESCE($2, email),
         role               = COALESCE($3, role),
         regiao             = COALESCE($4, regiao),
         regioes_operacao   = COALESCE($5, regioes_operacao),
         ativo              = COALESCE($6, ativo),
         updated_at         = NOW()
     WHERE id = $7
     RETURNING ${COLS_PUBLIC}`,
    [nome, email, role, regiao, regioes_operacao, ativo, id]
  );
  return rows[0] || null;
}

async function updatePassword(id, senhaHash) {
  const { rowCount } = await query(
    `UPDATE users SET senha = $1, updated_at = NOW() WHERE id = $2`,
    [senhaHash, id]
  );
  return rowCount > 0;
}

async function remove(id) {
  const { rowCount } = await query(`DELETE FROM users WHERE id = $1`, [id]);
  return rowCount > 0;
}

module.exports = { findAll, findById, findByEmail, create, update, updatePassword, remove };
