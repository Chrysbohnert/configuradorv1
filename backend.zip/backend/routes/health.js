import { Router } from 'express';
import { query } from '../db/pool.js';

const router = Router();

router.get('/', async (req, res) => {
  const start = Date.now();

  try {
    await query('SELECT 1');
    const latency = Date.now() - start;

    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: Math.floor(process.uptime()),
      database: { status: 'connected', latencyMs: latency },
      environment: process.env.NODE_ENV || 'development',
    });
  } catch (err) {
    res.status(503).json({
      status: 'error',
      timestamp: new Date().toISOString(),
      database: { status: 'disconnected', error: err.message },
    });
  }
});

export default router;
