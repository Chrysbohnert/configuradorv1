import { Router } from 'express';
import {
  getUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  login,
} from '../controllers/usersController.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = Router();

router.post('/login', login);

router.get('/', requireAuth, requireAdmin, getUsers);
router.get('/:id', requireAuth, getUserById);
router.post('/', requireAuth, requireAdmin, createUser);
router.put('/:id', requireAuth, requireAdmin, updateUser);
router.delete('/:id', requireAuth, requireAdmin, deleteUser);

export default router;
