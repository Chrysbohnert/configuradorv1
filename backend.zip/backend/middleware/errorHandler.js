export function errorHandler(err, req, res, next) {
  console.error('❌ Erro:', err.message);

  if (err.code === '23505') {
    return res.status(409).json({ error: 'Registro duplicado', detail: err.detail });
  }

  if (err.code === '23503') {
    return res.status(400).json({ error: 'Violação de chave estrangeira', detail: err.detail });
  }

  if (err.code === '42P01') {
    return res.status(500).json({ error: 'Tabela não encontrada', detail: err.message });
  }

  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    error: err.message || 'Erro interno do servidor',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
}

export function notFound(req, res) {
  res.status(404).json({ error: `Rota não encontrada: ${req.method} ${req.originalUrl}` });
}
