import { query } from '../db/pool.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export async function getUsers(req, res, next) {
  try {
    const { rows } = await query(
      `SELECT id, nome, email, role, regiao, regioes_operacao, ativo, created_at
       FROM users
       ORDER BY nome ASC`
    );
    res.json({ data: rows, count: rows.length });
  } catch (err) {
    next(err);
  }
}

export async function getUserById(req, res, next) {
  try {
    const { id } = req.params;
    const { rows } = await query(
      `SELECT id, nome, email, role, regiao, regioes_operacao, ativo, created_at
       FROM users
       WHERE id = $1`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json({ data: rows[0] });
  } catch (err) {
    next(err);
  }
}

export async function createUser(req, res, next) {
  try {
    const { nome, email, senha, role, regiao, regioes_operacao } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ error: 'nome, email e senha são obrigatórios' });
    }

    const senhaHash = await bcrypt.hash(senha, 10);

    const { rows } = await query(
      `INSERT INTO users (nome, email, senha, role, regiao, regioes_operacao, ativo)
       VALUES ($1, $2, $3, $4, $5, $6, true)
       RETURNING id, nome, email, role, regiao, regioes_operacao, ativo, created_at`,
      [nome, email, senhaHash, role || 'vendedor', regiao || null, regioes_operacao || null]
    );

    res.status(201).json({ data: rows[0] });
  } catch (err) {
    next(err);
  }
}

export async function updateUser(req, res, next) {
  try {
    const { id } = req.params;
    const { nome, email, role, regiao, regioes_operacao, ativo } = req.body;

    const { rows } = await query(
      `UPDATE users
       SET nome = COALESCE($1, nome),
           email = COALESCE($2, email),
           role = COALESCE($3, role),
           regiao = COALESCE($4, regiao),
           regioes_operacao = COALESCE($5, regioes_operacao),
           ativo = COALESCE($6, ativo)
       WHERE id = $7
       RETURNING id, nome, email, role, regiao, regioes_operacao, ativo, created_at`,
      [nome, email, role, regiao, regioes_operacao, ativo, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json({ data: rows[0] });
  } catch (err) {
    next(err);
  }
}

export async function deleteUser(req, res, next) {
  try {
    const { id } = req.params;
    const { rowCount } = await query('DELETE FROM users WHERE id = $1', [id]);

    if (rowCount === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json({ message: 'Usuário removido com sucesso' });
  } catch (err) {
    next(err);
  }
}

export async function login(req, res, next) {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ error: 'email e senha são obrigatórios' });
    }

    const { rows } = await query(
      `SELECT id, nome, email, senha, role, regiao, regioes_operacao, ativo
       FROM users
       WHERE email = $1`,
      [email.toLowerCase().trim()]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const user = rows[0];

    if (!user.ativo) {
      return res.status(403).json({ error: 'Conta desativada. Entre em contato com o administrador.' });
    }

    const senhaValida = await bcrypt.compare(senha, user.senha);
    if (!senhaValida) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, nome: user.nome },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    const { senha: _, ...userSemSenha } = user;

    res.json({ token, user: userSemSenha });
  } catch (err) {
    next(err);
  }
}
